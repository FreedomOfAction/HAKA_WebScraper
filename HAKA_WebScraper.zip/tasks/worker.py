from celery import Celery
from scraper.scraper import TradingScraper
from scraper.config import Config  # Ensure correct class name

config = Config()  # Instantiate the Config class

import logging
from scraper.config import config

# Correctly initialize Celery
celery = Celery("tasks", broker=config.REDIS_URL, backend=config.REDIS_URL)

celery.conf.update(
    result_backend=config.REDIS_URL,  # Required to track task status
    task_serializer="json",
    accept_content=["json"],
    result_expires=3600,  # Task results will be stored for 1 hour
)

@celery.task
def scrape_broker(url):
    """Runs the scraper as an asynchronous Celery task."""
    scraper = TradingScraper()
    raw_data = scraper.scrape_static(url)
    structured_data = clean_data(raw_data)
    scraper.close()
    return to_json(structured_data)
