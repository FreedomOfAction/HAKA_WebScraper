import os
from celery import Celery

# Ensure you have Redis configured correctly
REDIS_URL = "redis://localhost:6379/0"

app = Celery("tasks", broker=REDIS_URL, backend=REDIS_URL)  # Add backend

app.conf.update(
    result_backend=REDIS_URL,  # Required to track task status
    task_serializer="json",
    accept_content=["json"],
    result_expires=3600,  # Task results will be stored for 1 hour
)
